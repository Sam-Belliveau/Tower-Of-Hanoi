#pragma once
enum Type { start = 0, end = 2, misc = 1};